<?php
// 2009-04-16 By Marcos Cruz (http://alinome.net).

$T_HOME = 'Komenca paĝo';
$T_SYNTAX = 'Helpo pri vikiteksto';
$T_EDIT = 'Modifi';
$T_DONE = 'Konservi la modifojn';
$T_PREVIEW = 'Antaŭvidi';
$T_SEARCH = 'Serĉi';
$T_SEARCH_RESULTS = 'Serĉo-rezultoj';
$T_LIST_OF_ALL_PAGES = 'Listo de paĝoj';
$T_RECENT_CHANGES = 'Lastaj modifoj';
$T_LAST_CHANGED = 'Laste modifita je';
$T_HISTORY = 'Historio';
$T_RESTORE = 'Rekuperi';
$T_REV_DIFF = '<strong>Diferencoj inter la versioj de {REVISION1} kaj {REVISION2}.</strong>';
$T_REVISION = '<em>Ĉi versio estas de {TIME}. Vi povas {RESTORE} ĝin.</em>';
$T_PASSWORD = 'Pasvorto';
$T_EDIT_SUMMARY = 'Resumo pri la modifoj';
$T_ERASE_COOKIE = 'Forviŝi kuketojn';
$T_MOVE_TEXT = 'Nova nomo';
$T_DIFF = 'Diferencoj';
$T_CREATE_PAGE = 'Krei paĝon';
$T_SHOW_SOURCE = 'Montri la fontkodon';
$T_SHOW_PAGE = 'Montri la paĝon';
$T_PROTECTED_READ = 'Via pasvorto necesas por vidi la enhavon';
$T_EDIT_CONFLICT = 'Konflikto de modifoj: iu finmodifis ĉi paĝon dum vi modifadis ĝin. Antaŭ ol registri la paĝon, rekomendindas konsulti la lastajn {DIFF}-n.';
$T_WRONG_PASSWORD = 'Erara pasvorto';