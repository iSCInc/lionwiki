<?php
/*
	This file is actually never used but provides easier access to translators as they will
	probably translate from english.
*/
$T_HOME = 'Main page';
$T_SYNTAX = 'Syntax';
$T_DONE = 'Save changes';
$T_DISCARD_CHANGES = 'Discard changes';
$T_PREVIEW = 'Preview';
$T_SEARCH = 'Search';
$T_SEARCH_RESULTS = 'Search results';
$T_LIST_OF_ALL_PAGES = 'List of all pages';
$T_RECENT_CHANGES = 'Recent changes';
$T_LAST_CHANGED = 'Last changed';
$T_HISTORY = 'History';
$T_RESTORE = 'Restore';
$T_REV_DIFF = '<b>Difference between revisions from {REVISION1} and {REVISION2}.</b>';
$T_REVISION = "'''This revision is from {TIME}. You can {RESTORE} it.'''\n\n";
$T_PASSWORD = 'Password';
$T_EDIT = 'Edit';
$T_EDIT_SUMMARY = 'Summary of changes';
$T_EDIT_CONFLICT = 'Edit conflict: somebody saved this page after you started editing. See last {DIFF} before saving your changes.';
$T_SHOW_SOURCE = 'Show source';
$T_SHOW_PAGE = 'Show page';
$T_ERASE_COOKIE = 'Erase cookies';
$T_MOVE_TEXT = 'New name';
$T_DIFF = 'diff';
$T_CREATE_PAGE = 'Create page';
$T_PROTECTED_READ = 'You need to enter password to view content of site: ';
$T_WRONG_PASSWORD = 'Password is incorrect.';